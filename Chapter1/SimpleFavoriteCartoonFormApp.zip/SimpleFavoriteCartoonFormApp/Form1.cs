using System.Windows.Forms;

namespace SimpleFavoriteCartoonFormApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            string[] cartoons = { "Strawberry", "Blueberry", "Rasberry", "Plum", "Orange", "Lemon" };
            comboBox1.Items.AddRange(cartoons);

            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.SelectedIndex = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void viewBtn_Click(object sender, EventArgs e)
        {
            string selectedCharacter = comboBox1.SelectedItem.ToString();
            switch (selectedCharacter)
            {
                case "Strawberry":
                    pictureBox1.Image = Image.FromFile(@"C:\Users\MM329\Downloads\Strawberry Shortcake PNG Images (Transparent HD Photo Clipart).jfif");
                    break;
                case "Blueberry":
                    pictureBox1.Image = Image.FromFile(@"C:\Users\MM329\Downloads\Muffin Shortcake Blueberry pie Angel food cake, blueberry, blue, toddler png.jfif");
                    break;
                case "Rasberry":
                    pictureBox1.Image = Image.FromFile(@"C:\Users\MM329\Downloads\download.jfif");
                    break;
                case "Plum":
                    pictureBox1.Image = Image.FromFile(@"C:\Users\MM329\Downloads\download (1).jfif");
                    break;
                case "Orange":
                    pictureBox1.Image = Image.FromFile(@"C:\Users\MM329\Downloads\Orange Blossom but she is sad _((.jfif");
                    break;
                case "Lemon":
                    pictureBox1.Image = Image.FromFile(@"C:\Users\MM329\Downloads\Lemon meringue.jfif");
                    break;
                default:
                    pictureBox1.Image = null;
                    break;
            }
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
